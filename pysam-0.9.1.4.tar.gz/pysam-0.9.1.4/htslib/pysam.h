#ifndef PYSAM_H
#define PYSAM_H
#include "stdio.h"
extern FILE * pysam_stderr;
extern FILE * pysam_stdout;
extern int PYSAM_STDOUT_FILENO;
#endif
