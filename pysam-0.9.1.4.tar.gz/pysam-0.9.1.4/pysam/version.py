# pysam versioning information

__version__ = "0.9.1.4"

__samtools_version__ = "1.3.1"

__htslib_version__ = "1.3.1"
